package curahealthcare;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MakeAppointmentBeforeLogin {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
		// Make Appointment
		driver.findElement(By.id("btn-make-appointment")).click();
		// username
		driver.findElement(By.id("txt-username")).sendKeys("John Doe");
		// password
		driver.findElement(By.id("txt-password")).sendKeys("ThisIsNotAPassword");
		// login button
		driver.findElement(By.id("btn-login")).click();
		// Make appointment
		WebElement facility = driver.findElement(By.id("combo_facility"));
		Select fac = new Select(facility);
		fac.selectByVisibleText("Hongkong CURA Healthcare Center");
		// Check Box
		driver.findElement(By.id("chk_hospotal_readmission")).click();
		// Radio Button
		driver.findElement(By.id("radio_program_medicaid")).click();
		// Visit date
		WebElement visit = driver.findElement(By.id("txt_visit_date"));
		visit.click();
		visit.sendKeys("30/11/2023");
		// comment Box
		driver.findElement(By.id("txt_comment")).sendKeys("need urgent");
		// Appointmrnt Button
		driver.findElement(By.id("btn-book-appointment")).click();
		// Back to Home
		driver.findElement(By.xpath("//*[@id=\"summary\"]/div/div/div[7]/p/a")).click();
		driver.close();
	}

}
