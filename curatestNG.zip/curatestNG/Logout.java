package curatestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Logout {

	WebDriver driver;

	@BeforeTest
	public void homepage() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");

	    driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
}
	@Test
	public void logout() {
		// SIDE MENU
				driver.findElement(By.id("menu-toggle")).click();
				// side login
				driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a")).click();
				// username
				driver.findElement(By.id("txt-username")).sendKeys("John Doe");
				// password
				driver.findElement(By.id("txt-password")).sendKeys("ThisIsNotAPassword");
				// login button
				driver.findElement(By.id("btn-login")).click();
				// SIDE MENU
				driver.findElement(By.id("menu-toggle")).click();
				// LogOut
				driver.findElement(By.xpath("//*[@id=\"sidebar-wrapper\"]/ul/li[5]/a")).click();
	}
	@AfterTest
	public void close() {
		driver.close();
	}
}
