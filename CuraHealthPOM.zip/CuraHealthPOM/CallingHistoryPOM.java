package curahealthcare;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class CallingHistoryPOM {

	public static void main(String[] args) {
		

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
		History_POMFB m=PageFactory.initElements(driver, History_POMFB.class);
		m.menu.click();
		m.slogin.click();
		m.username.sendKeys("John Doe");
		m.password.sendKeys("ThisIsNotAPassword");
		m.loginbutton.click();
		m.facility.click();
		WebElement m1=driver.findElement(By.id("combo_facility"));
		Select f=new Select(m1);
		f.selectByVisibleText("Hongkong CURA Healthcare Center");
		m.checkbox.click();
		m.radio.click();
		m.date.click();
		m.date.sendKeys("30/11/2023");
		m.comment.sendKeys("dg	hdhw");
		m.appointbutton.click();
		m.B2H.click();
		m.smenu.click();
		m.history.click();
		m.HB2H.click();
		driver.close();

	}

}
