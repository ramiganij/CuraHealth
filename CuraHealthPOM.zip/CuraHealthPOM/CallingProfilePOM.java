package curahealthcare;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class CallingProfilePOM {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
		ProfilePOMFB m=PageFactory.initElements(driver, ProfilePOMFB.class);
		m.menu.click();
		m.slogin.click();
		m.username.sendKeys("John Doe");
		m.password.sendKeys("ThisIsNotAPassword");
		m.loginbutton.click();
		m.menu.click();
		m.profile.click();
		m.logout.click();
		driver.close();

	}

}
