package curahealthcare;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class POMMakeAppoint {

	@FindBy(id = "btn-make-appointment") WebElement appoint;
	@FindBy(id = "menu-toggle") WebElement menu;
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a") WebElement slogin;
	@FindBy(id="txt-username") WebElement username;
	@FindBy(id="txt-password") WebElement password;
	@FindBy(id="btn-login") WebElement loginbutton;
	@FindBy(id="combo_facility") WebElement facility;
	@FindBy(id="chk_hospotal_readmission") WebElement checkbox;
	@FindBy(id="radio_program_medicaid") WebElement radio;
	@FindBy(id="txt_visit_date") WebElement date;
	@FindBy(id="txt_comment") WebElement comment;
	@FindBy(id="btn-book-appointment") WebElement appointbutton;
	@FindBy(xpath = "//*[@id=\"summary\"]/div/div/div[7]/p/a") WebElement B2H;
}
