package curahealthcare;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class CallingLogOutPOM {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\jaggubhai\\Downloads\\chromedriver-win64 (1)\\chromedriver-win64\\chromedriver.exe");

		WebDriver driver = new ChromeDriver();
		driver.get("https://katalon-demo-cura.herokuapp.com/");
		driver.manage().window().maximize();
		LogoutPOMFB m=PageFactory.initElements(driver, LogoutPOMFB.class);
		m.menu.click();
		m.slogin.click();
		m.username.sendKeys("John Doe");
		m.password.sendKeys("ThisIsNotAPassword");
		m.loginbutton.click();
		m.smenu.click();
		m.LOGOUT.click();
		driver.close();

	}

}
