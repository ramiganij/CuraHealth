package curahealthcare;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ProfilePOMFB {

	@FindBy(id = "menu-toggle") WebElement menu;
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a") WebElement slogin;
	@FindBy(id="txt-username") WebElement username;
	@FindBy(id="txt-password") WebElement password;
	@FindBy(id="btn-login") WebElement loginbutton;
	@FindBy(id = "menu-toggle") WebElement smenu;
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[4]/a") WebElement profile;
	@FindBy(xpath = "//*[@id=\"profile\"]/div/div/div/p[2]/a") WebElement logout;
}
