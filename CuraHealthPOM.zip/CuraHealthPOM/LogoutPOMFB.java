package curahealthcare;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LogoutPOMFB {

	@FindBy(id = "menu-toggle") WebElement menu;
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[3]/a") WebElement slogin;
	@FindBy(id="txt-username") WebElement username;
	@FindBy(id="txt-password") WebElement password;
	@FindBy(id="btn-login") WebElement loginbutton;
	@FindBy(id = "menu-toggle") WebElement smenu;
	@FindBy(xpath = "//*[@id=\"sidebar-wrapper\"]/ul/li[5]/a") WebElement LOGOUT;

}
